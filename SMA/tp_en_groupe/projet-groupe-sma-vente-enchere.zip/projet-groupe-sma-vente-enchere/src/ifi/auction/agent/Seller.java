package ifi.auction.agent;

import jade.core.Agent;

public class Seller  extends Agent{
	
}
