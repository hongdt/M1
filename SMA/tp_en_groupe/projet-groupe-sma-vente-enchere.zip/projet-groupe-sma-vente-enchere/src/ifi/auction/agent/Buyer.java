package ifi.auction.agent;

import jade.core.Agent;

public class Buyer extends Agent{

}
