package ifi.auction.behaviour.main;

import jade.core.behaviours.OneShotBehaviour;

public class AddAuction extends OneShotBehaviour {

	@Override
	public void action() {
		// TODO Auto-generated method stub

	}

}