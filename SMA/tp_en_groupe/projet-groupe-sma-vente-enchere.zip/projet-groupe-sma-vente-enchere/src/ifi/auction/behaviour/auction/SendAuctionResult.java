package ifi.auction.behaviour.auction;

public class SendAuctionResult {

}
