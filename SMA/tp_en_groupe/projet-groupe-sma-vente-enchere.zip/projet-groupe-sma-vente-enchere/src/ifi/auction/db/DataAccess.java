package ifi.auction.db;

public class DataAccess {
	private static final String SQLITE_DRIVER = "org.sqlite.JDBC";
	private static final String DB_NAME = "jdbc:sqlite:enchere.db";

}
